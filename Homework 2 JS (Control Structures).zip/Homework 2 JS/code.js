const yearBorn = prompt("Enter the year you were born in:");
const year = Number(yearBorn);

const zodiacSign = (year - 4) % 12;
if (year > 2022){
    console.log("Please enter a valid year");
} else if (zodiacSign == 0){
    console.log("Your Chinese Zodiac Sign is Rat");
} else if (zodiacSign == 1){
    console.log("Your Chinese Zodiac Sign is Ox");
} else if (zodiacSign == 2){
    console.log("Your Chinese Zodiac Sign is Tiger");
} else if (zodiacSign == 3){
    console.log("Your Chinese Zodiac Sign is Rabbit");
} else if (zodiacSign == 4){
    console.log("Your Chinese Zodiac Sign is Dragon");
} else if (zodiacSign == 5){
    console.log("Your Chinese Zodiac Sign is Snake");
} else if (zodiacSign == 6){
    console.log("Your Chinese Zodiac Sign is Horse");
} else if (zodiacSign == 7){
    console.log("Your Chinese Zodiac Sign is Goat");
} else if (zodiacSign == 8){
    console.log("Your Chinese Zodiac Sign is Monkey");
} else if (zodiacSign == 9){
    console.log("Your Chinese Zodiac Sign is Rooster");
} else if (zodiacSign == 10){
    console.log("Your Chinese Zodiac Sign is Dog");
} else if (zodiacSign == 11){
    console.log("Your Chinese Zodiac Sign is Pig");
} 