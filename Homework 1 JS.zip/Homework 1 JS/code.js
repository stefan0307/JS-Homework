const numberofPhones = prompt("How many phones do you want to buy");
const numberPhones = Number(numberofPhones);

const pricePhone = 119.95;
const tax = 5;
const totalPrice = numberPhones * pricePhone;
const taxPrice = (numberPhones * pricePhone) * 5 / 100;
console.log("Your total will be:", totalPrice, "5% Tax is:", taxPrice);